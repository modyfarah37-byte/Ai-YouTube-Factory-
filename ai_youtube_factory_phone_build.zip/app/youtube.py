from .config import ROOT
from google_auth_oauthlib.flow import InstalledAppFlow
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
CLIENT = ROOT / "credentials" / "client_secrets.json"
TOKEN = ROOT / "credentials" / "youtube_token.json"

def service():
    creds = None
    if TOKEN.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN), SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not CLIENT.exists():
                raise RuntimeError("ضع credentials/client_secrets.json أولًا")
            flow = InstalledAppFlow.from_client_secrets_file(str(CLIENT), SCOPES)
            creds = flow.run_local_server(port=0)
        TOKEN.write_text(creds.to_json(), encoding="utf-8")
    return build("youtube","v3",credentials=creds)

def upload(video, content, cfg):
    yt = service()
    body = {
      "snippet": {
        "title": content["title"][:100],
        "description": content["description"][:5000],
        "tags": content.get("tags", []) + cfg.get("hashtags", []),
        "categoryId": cfg["youtube_category_id"],
        "defaultLanguage": cfg["language"]
      },
      "status": {
        "privacyStatus": cfg["privacy_status"],
        "selfDeclaredMadeForKids": False
      }
    }
    media = MediaFileUpload(str(video), mimetype="video/mp4", resumable=True)
    req = yt.videos().insert(part="snippet,status", body=body, media_body=media)
    response = None
    while response is None:
        _, response = req.next_chunk()
    return response["id"]
