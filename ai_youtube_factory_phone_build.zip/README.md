# AI YouTube Factory

نظام أوتوماتيكي لإنشاء فيديوهات YouTube:
موضوع → سكربت → صور AI → تعليق صوتي → مونتاج FFmpeg → عنوان/وصف/Tags → رفع YouTube.

## المتطلبات
- Python 3.11+
- FFmpeg
- OpenAI API key
- Google Cloud project مع YouTube Data API v3
- OAuth Desktop client JSON

## التشغيل
1. انسخ `.env.example` إلى `.env`.
2. ضع `OPENAI_API_KEY`.
3. ضع OAuth JSON في `credentials/client_secrets.json`.
4. عدّل `config.json`.
5. `pip install -r requirements.txt`
6. اختبار: `python -m app.main --once --no-upload`
7. تشغيل دائم: `python -m app.main`

ابدأ بـ `privacy_status: private` أثناء الاختبار.

## تطبيق Android
المجلد `android_app` هو تطبيق الموبايل. التطبيق يتحكم في محرك الفيديو على السيرفر عبر API.
ضع في السيرفر متغير البيئة `FACTORY_API_TOKEN` ثم شغّل:
`uvicorn app.server:app --host 0.0.0.0 --port 8000`

في التطبيق أدخل عنوان السيرفر وAPI Token.
