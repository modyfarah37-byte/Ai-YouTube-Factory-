import re
from pathlib import Path
from .config import ROOT, load_config
from .db import add_job, update_job, recent_topics
from .ai import choose_topic, make_content, generate_image, generate_tts
from .video import prepare_image, build_video
from .youtube import upload

def safe(s):
    return re.sub(r"[^a-zA-Z0-9\u0600-\u06FF_-]+","_",s)[:80]

def run_one(topic=None, do_upload=True):
    cfg = load_config()
    topic = topic or choose_topic(cfg, recent_topics())
    content = make_content(topic, cfg)
    add_job(topic, content["title"])
    update_job(topic, status="generating")

    work = ROOT/"output"/safe(content["title"])
    work.mkdir(parents=True, exist_ok=True)
    try:
        audio = work/"voice.mp3"
        generate_tts(content["script"], audio, cfg.get("tts_voice"))

        images, durations = [], []
        for i, scene in enumerate(content["scenes"]):
            raw, final = work/f"raw_{i:02d}.png", work/f"scene_{i:02d}.jpg"
            generate_image(scene["visual_prompt"], raw)
            prepare_image(raw, final)
            images.append(final)
            durations.append(scene["duration"])

        video = work/"video.mp4"
        build_video(images, durations, audio, video)
        update_job(topic, status="rendered", video_path=str(video))

        if do_upload:
            vid = upload(video, content, cfg)
            update_job(topic, status="uploaded", youtube_id=vid)
            return {"topic":topic, "video":str(video), "youtube_id":vid}
        return {"topic":topic, "video":str(video), "youtube_id":None}
    except Exception as e:
        update_job(topic, status="failed", error=str(e))
        raise
