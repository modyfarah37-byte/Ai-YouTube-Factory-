import subprocess
from pathlib import Path
from PIL import Image, ImageOps

def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode:
        raise RuntimeError(p.stdout[-5000:])
    return p.stdout

def prepare_image(src, dst):
    im = Image.open(src).convert("RGB")
    im = ImageOps.fit(im, (1080,1920), method=Image.Resampling.LANCZOS)
    im.save(dst, quality=95)

def build_video(images, durations, audio, out):
    work = Path(out).parent
    concat = work / "concat.txt"
    with open(concat, "w", encoding="utf-8") as f:
        for p,d in zip(images,durations):
            f.write(f"file '{Path(p).resolve()}'\n")
            f.write(f"duration {float(d):.2f}\n")
        f.write(f"file '{Path(images[-1]).resolve()}'\n")
    silent = work / "silent.mp4"
    run(["ffmpeg","-y","-f","concat","-safe","0","-i",str(concat),
         "-vf","scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2",
         "-r","30","-c:v","libx264","-pix_fmt","yuv420p","-an",str(silent)])
    run(["ffmpeg","-y","-i",str(silent),"-i",str(audio),
         "-map","0:v:0","-map","1:a:0","-c:v","libx264","-c:a","aac",
         "-shortest","-movflags","+faststart",str(out)])
    return out
