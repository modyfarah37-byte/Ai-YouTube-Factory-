# Android App

هذا مشروع Android Studio لتطبيق AI YouTube Factory.
افتح مجلد `android_app` في Android Studio ثم Build > Build APK.

التطبيق لا يحتوي مفاتيح OpenAI أو Google. هذه المفاتيح تبقى في السيرفر.
التطبيق يتصل بالـ backend عبر REST API.
