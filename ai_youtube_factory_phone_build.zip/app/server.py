import os
from fastapi import FastAPI, Header, HTTPException, BackgroundTasks
from pydantic import BaseModel
from .config import load_config
from .db import init_db, connect
from .pipeline import run_one

app = FastAPI(title="AI YouTube Factory API")
API_TOKEN = os.getenv("FACTORY_API_TOKEN", "change-me")

def auth(authorization):
    if authorization != f"Bearer {API_TOKEN}":
        raise HTTPException(status_code=401, detail="Unauthorized")

@app.on_event("startup")
def startup():
    init_db()

@app.get("/status")
def status(authorization: str = Header(default="")):
    auth(authorization)
    with connect() as c:
        rows = c.execute("SELECT status, COUNT(*) n FROM jobs GROUP BY status").fetchall()
        return {"config": load_config(), "jobs": {r["status"]: r["n"] for r in rows}}

class Job(BaseModel):
    topic: str = ""

@app.post("/jobs")
def create_job(job: Job, background_tasks: BackgroundTasks, authorization: str = Header(default="")):
    auth(authorization)
    background_tasks.add_task(run_one, job.topic or None, True)
    return {"accepted": True, "topic": job.topic}
