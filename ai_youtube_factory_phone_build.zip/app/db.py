import sqlite3
from .config import ROOT

DB = ROOT / "data" / "factory.sqlite3"

def connect():
    DB.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with connect() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS jobs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          topic TEXT UNIQUE,
          title TEXT,
          status TEXT,
          video_path TEXT,
          youtube_id TEXT,
          error TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )""")
        c.commit()

def add_job(topic, title=""):
    with connect() as c:
        c.execute("INSERT OR IGNORE INTO jobs(topic,title,status) VALUES(?,?,?)",
                  (topic, title, "created"))
        c.commit()

def update_job(topic, **fields):
    if not fields: return
    sets, vals = [], []
    for k, v in fields.items():
        sets.append(f"{k}=?")
        vals.append(v)
    sets.append("updated_at=CURRENT_TIMESTAMP")
    vals.append(topic)
    with connect() as c:
        c.execute(f"UPDATE jobs SET {','.join(sets)} WHERE topic=?", vals)
        c.commit()

def recent_topics(limit=30):
    with connect() as c:
        return [r["topic"] for r in c.execute(
            "SELECT topic FROM jobs ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()]
