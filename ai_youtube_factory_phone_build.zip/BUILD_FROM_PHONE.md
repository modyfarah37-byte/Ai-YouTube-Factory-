# بناء APK من الهاتف فقط

## الطريقة الأسهل: GitHub Actions

1. أنشئ حسابًا في GitHub.
2. أنشئ Repository جديدًا، مثل:
   `ai-youtube-factory`
3. ارفع محتويات هذا المشروع إلى المستودع.
4. بعد الرفع افتح:
   Actions → Build Android APK → Run workflow
5. انتظر حتى يصبح الـworkflow أخضر.
6. افتح نتيجة الـworkflow ثم Artifacts.
7. حمّل:
   `AI-YouTube-Factory-debug`
8. فك الضغط وثبّت `app-debug.apk` على هاتفك.

لا تحتاج Android Studio أو كمبيوتر.

## ملاحظة مهمة
هذا الـAPK هو لوحة تحكم للمحرك. محرك إنشاء الفيديو ورفع YouTube يحتاج Backend يعمل على سيرفر/جهاز متصل بالإنترنت. لا تضع OPENAI_API_KEY أو Google OAuth داخل APK.
